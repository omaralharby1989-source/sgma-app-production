# SGMA APP — iOS Xcode Build Instructions
Generated: 2026-06-13  |  API: https://sgma-app.org  |  Bundle ID: org.sgma.app
Version: 1.0 (build 1)  |  Deployment target: iOS 15.0

## OPEN IN XCODE
  File → Open → sgma-ios-xcode/ios/App/App.xcodeproj
  (NOT .xcworkspace — project uses SPM, not CocoaPods)
  Scheme: App   Destination: Any iOS Device (arm64)

## SIGNING
  Signing & Capabilities → Team: [your Apple Developer team]
  Automatically manage signing: ON
  Bundle ID: org.sgma.app

## LOCAL BUILD (from full repo)
  1.  pnpm install
  2.  VITE_API_BASE_URL=https://sgma-app.org VITE_ADMOB_TEST_MODE=true \
        pnpm --filter @workspace/sgma-app2 run build:cap
  3.  pnpm --filter @workspace/sgma-app2 exec cap sync ios
  4.  Open ios/App/App.xcodeproj → Product → Archive → Distribute

## XCODE CLOUD
  1.  Push repo to GitHub
  2.  App Store Connect → SGMA APP → Xcode Cloud → Get Started
  3.  Connect GitHub repo; Xcode detects ios/App/App.xcodeproj automatically
  4.  Workflow: Archive → Upload to App Store
  5.  ci_scripts/ci_post_clone.sh runs automatically (installs pnpm, builds web, syncs iOS)

## AdMob
  App ID (Info.plist): ca-app-pub-5363888403943121~7695424704
  Test banner (ACTIVE): ca-app-pub-3940256099942544/6300978111
  Real ads OFF by default (VITE_ADMOB_TEST_MODE=true baked in)
  ATT prompt text in Info.plist (Arabic): NSUserTrackingUsageDescription

## Reviewer account
  Email: reviewer@sgma-med.org  Password: SGMA-Review-2026!
  Role: MEMBER  URL: https://sgma-app.org
