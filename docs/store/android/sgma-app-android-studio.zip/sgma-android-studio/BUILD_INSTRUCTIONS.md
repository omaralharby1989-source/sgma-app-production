# SGMA APP — Android Studio Build Instructions

Generated: 2026-06-12
Production API: https://sgma-app.org
AdMob mode: TEST ONLY (real ads disabled)
App ID: org.sgma.app
Version: 1.0 (versionCode 1)

## What's in this package

```
sgma-android-studio/
  android/                  ← Open THIS folder in Android Studio
    app/
      src/main/
        assets/public/      ← Pre-built web app (already synced via cap sync)
        AndroidManifest.xml ← AdMob App ID + AD_ID permission included
      build.gradle
      capacitor.build.gradle
    gradle/wrapper/
    gradlew / gradlew.bat
    settings.gradle
    capacitor.settings.gradle  ← PATCHED to use ../plugins/ (self-contained)
    build.gradle
    variables.gradle
    gradle.properties
    capacitor-cordova-android-plugins/
  plugins/                  ← Capacitor plugin Android source (referenced by Gradle)
    capacitor-android/
    capacitor-community-admob/
    capacitor-splash-screen/
  capacitor.config.ts       ← Reference only (already baked into assets/)
  package.json              ← Reference only
  pnpm-lock.yaml            ← Reference only
  BUILD_INSTRUCTIONS.md     ← This file
```

## Step 1 — Open in Android Studio

1. Launch Android Studio
2. File → Open
3. Select the **`android/`** subfolder inside this package
   (NOT the zip root — open `sgma-android-studio/android/`)
4. Wait for Gradle sync to complete (downloads dependencies from Maven)

## Step 2 — Create a release signing keystore (first time only)

Option A — Play App Signing (recommended):
  Build an unsigned AAB and let Google manage the key.
  Skip keystore creation; Google signs on upload.

Option B — Local keystore:
  Build → Generate Signed Bundle / APK → Android App Bundle → Create new
  - Store path: choose somewhere OUTSIDE the project (e.g. ~/sgma-release.jks)
  - Validity: 30 years
  - Save passwords in a password manager — never commit them

  Then add to android/app/build.gradle (inside android {} block):
  ```gradle
  signingConfigs {
      release {
          storeFile     file(System.getenv("SGMA_KEYSTORE_PATH") ?: "/path/to/sgma-release.jks")
          storePassword System.getenv("SGMA_STORE_PASS")
          keyAlias      System.getenv("SGMA_KEY_ALIAS") ?: "sgma-release"
          keyPassword   System.getenv("SGMA_KEY_PASS")
      }
  }
  buildTypes {
      release {
          signingConfig signingConfigs.release
          minifyEnabled false
          proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
      }
  }
  ```

## Step 3 — Build the release AAB

From the terminal inside Android Studio (or from android/ directory):

```bash
./gradlew bundleRelease
```

Output: app/build/outputs/bundle/release/app-release.aab

## Step 4 — Upload to Google Play

1. Go to Play Console → your app → Closed testing → Create release
2. Upload app-release.aab
3. Release notes: copy from docs/store/android/release-notes-*.txt in the repo

## AdMob configuration

- App ID (in AndroidManifest.xml): ca-app-pub-5363888403943121~7695424704
- Test banner ad unit (ACTIVE in this build): ca-app-pub-3940256099942544/6300978111
- Real banner ad unit (INACTIVE): ca-app-pub-5363888403943121/7308411896
- Real ads are controlled by VITE_ADMOB_TEST_MODE env var at web build time.
  This build was compiled with VITE_ADMOB_TEST_MODE=true — real ads will NOT show.

## Demo reviewer account (for Google Play review access)

Email: playreviewer@sgma-app.org
Password: PlayReview2026!Sgma
Role: MEMBER (no admin access)
Production URL: https://sgma-app.org

Full instructions for the Play Console "App access" field:
  See docs/store/android/app-access-instructions.txt in the repo.

## Requirements

- JDK 17 (Android Studio bundles this; ensure Project SDK is set to JDK 17)
- Android SDK with Build Tools 35+
- Gradle 8.x (the wrapper downloads it automatically)
- Internet access (Maven dependency download on first sync)

## Important notes

- The web assets (HTML/CSS/JS) are ALREADY built and synced into
  android/app/src/main/assets/public/ — you do NOT need to re-run Vite.
- capacitor.settings.gradle has been patched to use the local plugins/ folder.
  Do NOT run "cap sync" or "cap update" from this standalone package.
- The production API URL https://sgma-app.org is baked into the web bundle.
