================================================================================
SGMA iOS BUILD 2 — NEW PACKAGING STRATEGY (no "Missing package product" failure)
Version 1.0 · Build 2 · Bundle org.sgma.app · Safe-area + AdMob web bundle
================================================================================

--------------------------------------------------------------------------------
1) WHY THE PREVIOUS ZIP STILL FAILS WITH "Missing package product 'CapApp-SPM'"
--------------------------------------------------------------------------------
The project file itself is NOT broken. It is functionally identical to the Build 1
project that you already archived and uploaded successfully (proof in section 6).

The error is caused by COLD SWIFT PACKAGE RESOLUTION, not by a missing or corrupt
file:

  * CapApp-SPM is a LOCAL Swift package, but it only re-exports REMOTE packages:
      - capacitor-swift-pm  -> products "Capacitor" and "Cordova"
      - capacitor-community/admob -> GoogleMobileAds + UserMessagingPlatform
      - capacitor/splash-screen
  * When you clear DerivedData AND SourcePackages and then open the project,
    Xcode must RE-DOWNLOAD and RE-RESOLVE all of those remote packages from
    GitHub / Google's package servers BEFORE it can build the CapApp-SPM product.
  * On MacinCloud, if that one-shot cold resolve does not fully complete
    (restricted/slow network, a different Xcode version, or the resolve step not
    being triggered when opening App.xcodeproj directly), Xcode reports the local
    product as "Missing package product 'CapApp-SPM'".
  * Clearing the caches actually makes this WORSE for a single open, because it
    forces a FULL cold re-resolve instead of reusing already-resolved packages.

Conclusion: the blocker is the requirement to re-resolve packages from scratch —
NOT anything we can fix by editing files inside the ZIP.

--------------------------------------------------------------------------------
2) THE CHANGED STRATEGY (this is different from every previous ZIP)
--------------------------------------------------------------------------------
Stop making Xcode resolve packages from scratch. Re-use the Build 1 Xcode project
that ALREADY archived on your Mac (its packages are already resolved there), and
apply ONLY the two real Build 2 changes on top of it:

      (a) the Build 2 web bundle (safe-area + AdMob fix) -> App/App/public
      (b) the build number -> 2     (version stays 1.0)

Because you reuse your already-working, already-resolved project, Xcode never has
to re-resolve CapApp-SPM, so the "Missing package product" error cannot occur.

This ZIP therefore leads with an OVERLAY (just the web bundle) instead of a fresh
project that would have to be resolved again.

--------------------------------------------------------------------------------
3) WHAT IS IN THIS ZIP
--------------------------------------------------------------------------------
1_RECOMMENDED_overlay_for_your_working_build1/
    App/public/...        <- the Build 2 web bundle (safe-area + AdMob). This is
                             ALL you need to drop into your working Build 1 project.

2_OPTIONAL_full_project_only_if_you_lost_build1/
    artifacts/sgma-app2/ios/App/...   <- a complete project (same package graph as
                             Build 1 + Build 2 assets + build number 2). Use this
                             ONLY if you no longer have your Build 1 project.
                             WARNING: this path DOES require Xcode to resolve
                             packages and can hit the same cold-resolve error in a
                             restricted environment — Option 1 is the safe path.

README_BUILD2.txt          <- this file.

--------------------------------------------------------------------------------
4) EXACT ARCHIVE STEPS
--------------------------------------------------------------------------------
OPTION 1  (RECOMMENDED — guaranteed if Build 1 archived):
  1. Open your EXISTING Build 1 Xcode project — the same one you archived and
     uploaded for Build 1. Do NOT clear DerivedData / SourcePackages this time.
  2. Quit Xcode.
  3. In Finder, open the project's   App/App/public   folder.
     Delete its contents, then copy in EVERYTHING from this ZIP's
       1_RECOMMENDED_overlay_for_your_working_build1/App/public/
     (so App/App/public/index.html and App/App/public/assets/... are the new ones).
  4. Re-open the project in Xcode.
  5. Select the "App" target -> General (Identity). Confirm:
        Version = 1.0      Build = 2
     If Build still shows 1, set it to 2.
  6. Top toolbar: choose destination "Any iOS Device (arm64)".
  7. Product -> Archive.
  8. In the Organizer: Distribute App -> App Store Connect -> Upload.
  No package resolution happens, so "Missing package product" cannot appear.

OPTION 2  (only if you lost your Build 1 project):
  1. Unzip 2_OPTIONAL_full_project_only_if_you_lost_build1/.
  2. Open  artifacts/sgma-app2/ios/App/App.xcodeproj  in Xcode.
  3. Wait for "Resolve Package Versions" to FINISH (needs internet; do not clear
     caches). If it shows "Missing package product", use File -> Packages ->
     Resolve Package Versions and wait for it to complete.
  4. Then follow steps 5-8 above.

--------------------------------------------------------------------------------
5) ANSWERS TO THE REQUIRED QUESTIONS
--------------------------------------------------------------------------------
* What changed vs the failed ZIP:
    The deliverable is no longer "a fresh project to resolve". It now LEADS with a
    web-bundle overlay meant to be dropped into your already-resolved Build 1
    project, removing the cold package-resolution step that caused the failure.
* Is CapApp-SPM still required?
    In Option 1 it is still present in your project but is NEVER re-resolved (your
    Build 1 project already resolved it), so it cannot fail. Option 2 still uses
    CapApp-SPM and still needs resolution.
* Does Xcode need to resolve packages?
    Option 1: NO. Option 2: YES (this is why Option 1 is recommended).
* Bundle / version: org.sgma.app · Version 1.0 · Build 2 (unchanged from Build 1
    except the build number).

--------------------------------------------------------------------------------
6) PROOF THE PACKAGE GRAPH MATCHES THE BUILD 1 ARCHIVE BASE
--------------------------------------------------------------------------------
Compared against the proven-good Build 1 commit ca3b5d90 on GitHub:
  * CapApp-SPM/Package.swift .................. BYTE-IDENTICAL to Build 1
  * Vendors/admob/Package.swift .............. BYTE-IDENTICAL to Build 1
  * Vendors/splash-screen/Package.swift ...... BYTE-IDENTICAL to Build 1
  * App.xcodeproj/project.pbxproj ............ same package graph, same UUIDs,
      single local CapApp-SPM reference; only functional change is
      CURRENT_PROJECT_VERSION 1 -> 2.
  * App/Info.plist (incl. GADApplicationIdentifier + SKAdNetwork) — same as Build 1.
  * Only intended Build 2 deltas: build number = 2, and the App/public web bundle
    (safe-area viewport-fit=cover + AdMob fix).

Run scripts/verify-ios-xcode-ready.sh from the repo to re-check all of the above
(exit code 0 = all checks pass).
================================================================================
