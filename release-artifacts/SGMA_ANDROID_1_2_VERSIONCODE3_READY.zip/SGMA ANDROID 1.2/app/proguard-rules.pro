# Keep WebView JS interface (none used, but safe for future)
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class org.sgma.app.** { *; }
