SGMA APP — Android Update 1.2 (versionCode 3)
=============================================

This is a clean NATIVE Android WebView wrapper for SGMA APP.
It loads the production web app https://sgma-app.org full-screen.

This build uses a PURE native Android WebView. It does NOT bundle any
hybrid web-to-native framework, and it does NOT include any native advertising
SDK of any kind. Only minimal AndroidX libraries are used (appcompat, core-ktx,
activity, swiperefreshlayout).

App identity (already configured — do NOT change):
- Application ID / package : org.sgma.app
- versionName             : 1.2
- versionCode             : 3
- App display name        : SGMA APP
- Main URL                : https://sgma-app.org
- minSdk 24 / targetSdk 34 / compileSdk 34

------------------------------------------------------------
GUI-ONLY STEPS FOR OMAR (Android Studio)
------------------------------------------------------------
A. Open Android Studio.
   File > Open... and select the folder:
        SGMA ANDROID 1.2
   (the folder that contains settings.gradle and the app/ folder)
   Let Gradle sync finish. Android Studio will download Gradle 8.9,
   Android Gradle Plugin 8.6.0, Kotlin 1.9.24 and SDK 34 automatically
   if they are not already installed. Use a JDK 17 (Android Studio bundles one).

B. Confirm identity in app/build.gradle:
   - applicationId 'org.sgma.app'
   - versionName '1.2'
   - versionCode 3

C. Build > Generate Signed Bundle / APK...

D. Choose "Android App Bundle" and click Next.

E. Use the EXISTING upload keystore (do NOT create a new key):
   Key store path:
        C:\Users\lordh\OneDrive\Desktop\SGMA0\sgma-release-key.jks
   Enter your key store password, key alias, and key password.

F. Select build variant: release.

G. Click "Create" / "Finish" to export the signed AAB.
   The signed .aab will be written under:
        app/release/app-release.aab   (or the location Android Studio reports)

H. Upload to Google Play Console:
   SGMA APP > Testing > Closed testing > Manage track >
   Create new release > Upload the .aab > Review release > Roll out to Closed testing.

------------------------------------------------------------
IMPORTANT
------------------------------------------------------------
- You MUST sign with the SAME upload key used for previous SGMA releases
  (sgma-release-key.jks). Signing with a different key will be REJECTED by
  Google Play as an update.
- No keystore or passwords are stored in this project. Signing happens only
  on your machine inside Android Studio.
- This build intentionally has NO native ad banner of any kind. Any ads must be served by
  the web app itself, so there is no overlap with the bottom navigation.
